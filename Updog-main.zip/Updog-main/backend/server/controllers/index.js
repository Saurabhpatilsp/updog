import * as user from './user'
import * as posts from './posts'
import * as test from './testapi'
import * as image from './image'
import * as interests from './interests'
import * as tags from './tags'
import * as search from './search'

export { user, posts, image, interests, test, tags, search }
