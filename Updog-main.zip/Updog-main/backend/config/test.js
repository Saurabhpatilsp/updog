module.exports = {
  PORT: 8000,
  DB: {
    username: 'updogDev',
    password: 'password',
    database: 'updog',
    host: '127.0.0.1',
    port: 3306,
    dialect: 'mysql',
    logging: false,
  },
  DEV: false,
}
