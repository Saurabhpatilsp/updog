const SERVER_URL = 'http://localhost:8000/api'
export default SERVER_URL
