import NotifView from './RepliedNotificationView'

const RepliedNotificationController = ({ replier, post }) => (
  <NotifView replier={replier} post={post} />
)

export default RepliedNotificationController
