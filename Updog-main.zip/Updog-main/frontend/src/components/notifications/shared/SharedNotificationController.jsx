import SharedNotifView from './SharedNotificationView'

const SharedNotificationController = ({ sharer, post }) => (
  <SharedNotifView sharer={sharer} post={post} />
)

export default SharedNotificationController
