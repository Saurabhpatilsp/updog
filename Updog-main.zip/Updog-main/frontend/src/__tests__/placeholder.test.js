// Placeholder test to be removed once frontend unit tests have been added

it('sums numbers', () => {
  expect(1).toEqual(1)
})
