import LoadingView from './LoadingView'

/**
 * This page is the loading page across the app
 */
const LoadingController = () => <LoadingView />

export default LoadingController
