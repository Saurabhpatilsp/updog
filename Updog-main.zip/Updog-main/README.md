# SE701-Updog
Updog is an open-source social media webapp intended to allow everyday people to share their thoughts in a welcoming community. This project is created by students at the University of Auckland studying SOFTENG 701.

## Quick-Start
To learn how to clone, install and run our frontend or backend, check out these links:
- [Frontend](frontend/README.md)
- [Backend](backend/README.md)

We haven't got the whole site up and working yet, so stay tuned for info about deployment.

## How to Contribute
[See our contribution guidelines here](CONTRIBUTING.md)

## Code of Conduct
[See our code of conduct here](CODE_OF_CONDUCT.md)

## License Information
[Updog is licensed under the MIT License](LICENSE)